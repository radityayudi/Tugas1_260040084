package id.ac.stikombali.katalog_buku

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
