import 'package:flutter/foundation.dart';
import 'book_model.dart';
import 'book_database.dart';

class BookViewModel extends ChangeNotifier {
  List<Book> _books = [];
  bool _isLoading = false;

  List<Book> get books => _books;
  bool get isLoading => _isLoading;

  // Ambil data untuk ditampilkan di layar
  Future<void> fetchBooks() async {
    _isLoading = true;
    notifyListeners();

    try {
      _books = await BookDatabase.instance.readAllBooks();
    } catch (e) {
      debugPrint("Error: $e");
    }

    _isLoading = false;
    notifyListeners();
  }

  // Tambah buku
  Future<void> addBook(String judul, String kategori, String tanggal, String status) async {
    final newBook = Book(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      judul: judul,
      kategori: kategori,
      tanggal: tanggal,
      status: status,
    );
    await BookDatabase.instance.createBook(newBook);
    await fetchBooks();
  }

  // Ubah buku (Update)
  Future<void> editBook(Book book, String judul, String kategori, String tanggal, String status) async {
    book.judul = judul;
    book.kategori = kategori;
    book.tanggal = tanggal;
    book.status = status;

    await BookDatabase.instance.updateBook(book);
    await fetchBooks();
  }

  // Hapus buku (Delete)
  Future<void> removeBook(String id) async {
    await BookDatabase.instance.deleteBook(id);
    await fetchBooks();
  }
}