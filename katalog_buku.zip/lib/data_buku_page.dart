import 'package:flutter/material.dart';
import 'book_model.dart';
import 'book_viewmodel.dart';
import 'form_buku_page.dart';

class DataBukuPage extends StatefulWidget {
  const DataBukuPage({super.key});

  @override
  State<DataBukuPage> createState() => _DataBukuPageState();
}

class _DataBukuPageState extends State<DataBukuPage> {
  final BookViewModel _viewModel = BookViewModel();

  @override
  void initState() {
    super.initState();
    _viewModel.fetchBooks();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Katalog Buku'), centerTitle: true),
      body: AnimatedBuilder(
        animation: _viewModel,
        builder: (context, child) {
          if (_viewModel.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          if (_viewModel.books.isEmpty) {
            return const Center(child: Text('Belum ada data buku. Tekan + untuk menambah.'));
          }
          return ListView.builder(
            itemCount: _viewModel.books.length,
            itemBuilder: (context, index) {
              final book = _viewModel.books[index];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: ListTile(
                  title: Text(book.judul, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('Kategori: ${book.kategori}\nTanggal Pendataan: ${book.tanggal}\nStatus: ${book.status}'),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Tombol Edit (Ubah)
                      IconButton(
                        icon: const Icon(Icons.edit, color: Color.fromARGB(255, 92, 203, 255)),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => FormBukuPage(viewModel: _viewModel, book: book),
                            ),
                          );
                        },
                      ),
                      // Tombol Hapus
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _konfirmasiHapus(context, book),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FormBukuPage(viewModel: _viewModel),
            ),
          );
        },
        backgroundColor:const Color.fromARGB(255, 162, 213, 255),
        child: const Icon(Icons.add),
        
      ),
    );
  }

  void _konfirmasiHapus(BuildContext context, Book book) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Buku'),
        content: Text('Yakin ingin menghapus "${book.judul}"?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), style: TextButton.styleFrom(foregroundColor: 
            Colors.blue),child: const Text('Batal')),
          TextButton(
            onPressed: () {
              _viewModel.removeBook(book.id);
              Navigator.pop(context);
            },
            
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}