import 'package:flutter/material.dart';
import 'book_model.dart';
import 'book_viewmodel.dart';

class FormBukuPage extends StatefulWidget {
  final BookViewModel viewModel;
  final Book? book; // Jika null berati Tambah, jika ada isinya berarti Edit

  const FormBukuPage({super.key, required this.viewModel, this.book});

  @override
  State<FormBukuPage> createState() => _FormBukuPageState();
}

class _FormBukuPageState extends State<FormBukuPage> {
  final _formKey = GlobalKey<FormState>();
  
  late TextEditingController _judulController;
  late TextEditingController _kategoriController;
  late TextEditingController _tanggalController;
  String _selectedStatus = 'Tersedia';

  final List<String> _statusList = ['Tersedia', 'Dipinjam'];

  @override
  void initState() {
    super.initState();
    // Jika mode edit, isi form dengan data buku yang lama
    _judulController = TextEditingController(text: widget.book?.judul ?? '');
    _kategoriController = TextEditingController(text: widget.book?.kategori ?? '');
    _tanggalController = TextEditingController(text: widget.book?.tanggal ?? '');
    if (widget.book != null) {
      _selectedStatus = widget.book!.status;
    }
  }

  @override
  void dispose() {
    _judulController.dispose();
    _kategoriController.dispose();
    _tanggalController.dispose();
    super.dispose();
  }
  // Fungsi untuk memunculkan kalender (Date Picker)
  Future<void> _pilihTanggal(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(), // Tanggal awal saat kalender dibuka
      firstDate: DateTime(2000),    // Batas minimal tahun
      lastDate: DateTime(2100),     // Batas maksimal tahun
    );

    if (pickedDate != null) {
      // Format tanggal menjadi string "YYYY-MM-DD" lalu masukkan ke controller
      setState(() {
        _tanggalController.text = 
            "${pickedDate.year}-${pickedDate.month.toString().padLeft(2, '0')}-${pickedDate.day.toString().padLeft(2, '0')}";
      });
    }
  }

  void _simpan() {
    if (_formKey.currentState!.validate()) {
      if (widget.book == null) {
        // Tambah baru
        widget.viewModel.addBook(
          _judulController.text,
          _kategoriController.text,
          _tanggalController.text,
          _selectedStatus,
        );
      } else {
        // Edit / Update
        widget.viewModel.editBook(
          widget.book!,
          _judulController.text,
          _kategoriController.text,
          _tanggalController.text,
          _selectedStatus,
        );
      }

      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.book == null ? 'Buku berhasil ditambahkan!' : 'Buku berhasil diperbarui!'),
          backgroundColor:Colors.blue,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isEdit = widget.book != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Ubah Buku' : 'Tambah Buku Baru'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _judulController,
                decoration: const InputDecoration(labelText: 'Judul Buku', border: OutlineInputBorder()),
                validator: (v) => v!.isEmpty ? 'Judul tidak boleh kosong!' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _kategoriController,
                decoration: const InputDecoration(labelText: 'Kategori', border: OutlineInputBorder()),
                validator: (v) => v!.isEmpty ? 'Kategori harus diisi!' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _tanggalController,
                readOnly: true, // Pengguna tidak bisa mengetik manual, wajib lewat kalender
                onTap: () => _pilihTanggal(context), // Saat kotak diklik, kalender muncul
                decoration: const InputDecoration(
                  labelText: 'Tanggal Pendataan',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.calendar_today),
                ),
                validator: (v) => v!.isEmpty ? 'Tanggal harus dipilih!' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _selectedStatus,
                decoration: const InputDecoration(labelText: 'Status Buku', border: OutlineInputBorder()),
                items: _statusList.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
                onChanged: (val) => setState(() => _selectedStatus = val!),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _simpan,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
                child: Text(isEdit ? 'SIMPAN PERUBAHAN' : 'TAMBAH BUKU'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}