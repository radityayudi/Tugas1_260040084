class Book {
  final String id;
  String judul;
  String kategori;
  String tanggal;
  String status;

  Book({
    required this.id,
    required this.judul,
    required this.kategori,
    required this.tanggal,
    required this.status,
  });

  // Mengubah objek Book menjadi Map (untuk disimpan ke database SQLite)
  Map<String, dynamic> toJson() => {
        'id': id,
        'judul': judul,
        'kategori': kategori,
        'tanggal': tanggal,
        'status': status,
      };

  // Mengubah Map kembali menjadi objek Book (saat dibaca dari database SQLite)
  factory Book.fromJson(Map<String, dynamic> json) => Book(
        id: json['id'],
        judul: json['judul'],
        kategori: json['kategori'],
        tanggal: json['tanggal'],
        status: json['status'],
      );
}